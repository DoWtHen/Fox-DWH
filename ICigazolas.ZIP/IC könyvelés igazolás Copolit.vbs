' ***********************************
' *         VBScript �rta:          *
' *            DoWtHen              *
' *  a Dakadran Oldala weboldalnak  *
' *       https://dakadran.hu       *
' *      IC k�nyvel�s igazol�sa     *
' *    COPOLIT r�vid�tett verzi�    *
' *           2026.08.28.           *
' ***********************************

' === SAP GUI inicializ�l�s ===
Set SapGuiAuto = GetObject("SAPGUI")
Set application = SapGuiAuto.GetScriptingEngine
Set connection = application.Children(0)
Set session = connection.Children(0)

Dim Felhasznalo, Anyagnev, Datum

' === InputBox � Felhaszn�l� ===
Felhasznalo = InputBox("Add meg a nevet:", "Anyag kiv�laszt�sa", "ZBAKO")
If Felhasznalo = "" Then
    MsgBox "Akkor kil�pek", vbOKOnly, "M�gsem"
    WScript.Quit
End If

WScript.Sleep 500

' === InputBox � Anyagn�v ===
Anyagnev = InputBox("Add meg az anyagnevet:", "Anyag kiv�laszt�sa")
If Anyagnev = "" Then
    MsgBox "Akkor kil�pek", vbOKOnly, "M�gsem"
    WScript.Quit
End If

WScript.Sleep 500

' === Mai d�tum SAP form�tumban (YYYYMMDD) ===
Datum = Year(Date) & Right("0" & Month(Date), 2) & Right("0" & Day(Date), 2)

' === LT22 megnyit�sa ===
session.findById("wnd[0]/tbar[0]/okcd").Text = "/nLT22"
session.findById("wnd[0]").sendVKey 0

' === LT22 sz�r�si opci�k ===
session.findById("wnd[0]/usr/chkT3_SENAC").Selected = True
session.findById("wnd[0]/usr/chkT3_SERUE").Selected = True
session.findById("wnd[0]/usr/radT3_QUITA").Select

' === Tov�bbi sz�r�si felt�telek megnyit�sa ===
session.findById("wnd[0]/tbar[1]/btn[16]").Press

' === Node-fa egyszer�s�tett kezel�se ===
Set tree = session.findById("wnd[0]/usr/cntlSUB_CONTAINER/shell")

' Felhaszn�l� node
tree.expandNode "1"
tree.doubleClickNode "10"

session.findById("wnd[0]/usr/ssubSUBSCREEN_CONTAINER:SAPLSSEL:1106/txt%%DYN001-LOW").Text = Felhasznalo
session.findById("wnd[0]").sendVKey 0

' Anyagn�v node
tree.expandNode "66"
tree.doubleClickNode "72"

session.findById("wnd[0]/usr/ssubSUBSCREEN_CONTAINER:SAPLSSEL:1106/ctxt%%DYN002-LOW").Text = Anyagnev
session.findById("wnd[0]").sendVKey 0

' === D�tum be�ll�t�sa (LOW) ===
session.findById("wnd[0]/usr/ctxtBDATU-LOW").SetFocus
session.findById("wnd[0]").sendVKey 4
session.findById("wnd[1]/usr/cntlCONTAINER/shellcont/shell").selectionInterval = Datum & "," & Datum

' === D�tum be�ll�t�sa (HIGH) ===
session.findById("wnd[0]/usr/ctxtBDATU-HIGH").SetFocus
session.findById("wnd[0]").sendVKey 4
session.findById("wnd[1]/usr/cntlCONTAINER/shellcont/shell").selectionInterval = Datum & "," & Datum

' === Lek�rdez�s ind�t�sa ===
session.findById("wnd[0]/tbar[1]/btn[8]").Press
