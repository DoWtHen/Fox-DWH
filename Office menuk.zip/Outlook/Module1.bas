Attribute VB_Name = "Module1"
Sub Kijelolt_Emailek_Athelyezese_Tallozas()
' DoWtHen Makr� 2026.05.01
' CSAK A KIJEL�LT LEVELEKET M�SOLJA �T MAPPA TALL�Z�S ABLAKKAL
    
    On Error GoTo ErrHandler

    Dim ns As Outlook.NameSpace
    Dim destFolder As Outlook.MAPIFolder
    Dim itm As Object

  If MsgBox("A kijel�lt levelek �thelyez�se Tall�z�s ablakkal." & vbCrLf & "Biztosan futtatod a makr�t?", vbQuestion + vbYesNo, "Meger�s�t�s") = vbNo Then
    MsgBox "Akkor kil�pek."
    Exit Sub
  End If

    Set ns = Application.GetNamespace("MAPI")

    ' --- Mappa tall�z� ablak megnyit�sa ---
    Set destFolder = ns.PickFolder
    If destFolder Is Nothing Then
        MsgBox "Nincs kiv�lasztott c�lmappa.", vbExclamation
        Exit Sub
    End If

    If Application.ActiveExplorer.Selection.Count = 0 Then
        MsgBox "Nincs kijel�lt elem.", vbExclamation
        Exit Sub
    End If

    For Each itm In Application.ActiveExplorer.Selection
        If TypeOf itm Is Outlook.MailItem Then
            itm.Move destFolder
        End If
    Next itm

    MsgBox "�thelyez�s k�sz!", vbInformation
    Exit Sub

ErrHandler:
    MsgBox "Hiba t�rt�nt: " & Err.Description, vbCritical
End Sub


Sub Kijelolt_Emailek_Athelyezese()
' DoWtHen Makr� 2026.05.01
' CSAK A KIJEL�LT LEVELEKET M�SOLJA �T

    On Error GoTo ErrHandler

    Dim ns As Outlook.NameSpace
    Dim destFolder As Outlook.MAPIFolder
    Dim itm As Object

  If MsgBox("A kijel�lt levelek �thelyez�se az Arch�vum mapp�ba." & vbCrLf & "Biztosan futtatod a makr�t?", vbQuestion + vbYesNo, "Meger�s�t�s") = vbNo Then
    MsgBox "Akkor kil�pek."
    Exit Sub
  End If

    Set ns = Application.GetNamespace("MAPI")

    ' ?? IDE �RD A C�L MAPP�T
    ' P�lda: Inbox � Archiv�l�s
    Set destFolder = ns.GetDefaultFolder(olFolderInbox).Folders("Archiv�l�s")

    If Application.ActiveExplorer.Selection.Count = 0 Then
        MsgBox "Nincs kijel�lt elem.", vbExclamation
        Exit Sub
    End If

    For Each itm In Application.ActiveExplorer.Selection
        If TypeOf itm Is Outlook.MailItem Then
            itm.Move destFolder
        End If
    Next itm

    MsgBox "�thelyez�s k�sz.", vbInformation
    Exit Sub

ErrHandler:
    MsgBox "Hiba t�rt�nt: " & Err.Description, vbCritical
End Sub


Sub Minden_Email_Athelyezese()
' DoWtHen Makr� 2026.05.01
' MINDEN LEVELET �TM�SOL AMI A BEJ�V� MAPP�BAN VAN

    On Error GoTo ErrHandler

    Dim ns As Outlook.NameSpace
    Dim inbox As Outlook.MAPIFolder
    Dim destFolder As Outlook.MAPIFolder
    Dim itm As Outlook.MailItem

  If MsgBox("Minden lev�l �thelyez�se az Arch�vum mapp�ba." & vbCrLf & "Biztosan futtatod a makr�t?", vbQuestion + vbYesNo, "Meger�s�t�s") = vbNo Then
    MsgBox "Akkor kil�pek."
    Exit Sub
  End If

    Set ns = Application.GetNamespace("MAPI")
    Set inbox = ns.GetDefaultFolder(olFolderInbox)

    ' ?? IDE �RD A C�L MAPP�T
    Set destFolder = inbox.Folders("Archiv�l�s")

    While inbox.Items.Count > 0
        If TypeOf inbox.Items(1) Is Outlook.MailItem Then
            inbox.Items(1).Move destFolder
        Else
            inbox.Items(1).Delete
        End If
    Wend

    MsgBox "Minden lev�l �thelyezve.", vbInformation
    Exit Sub

ErrHandler:
    MsgBox "Hiba t�rt�nt: " & Err.Description, vbCritical
End Sub


Sub PrintFolders(ByVal fld As Outlook.MAPIFolder, ByVal indent As String)
' DoWtHen Makr� 2026.05.01
' Az Immediate ablakban sorolja fel az Outlook mappaneveket
' Ez a f�ggv�ny r�sze!

    Dim subFld As Outlook.MAPIFolder

    Debug.Print indent & fld.Name

    For Each subFld In fld.Folders
        PrintFolders subFld, indent & "    "
    Next subFld
End Sub


Sub Mappanevek_Listaja()
' DoWtHen Makr� 2026.05.01
' Az Immediate ablakban sorolja fel az Outlook mappaneveket

    Dim ns As Outlook.NameSpace
    Dim root As Outlook.MAPIFolder

    Set ns = Application.GetNamespace("MAPI")
    Set root = ns.Folders(1) ' els� postafi�k

    Debug.Print "=== Mapp�k list�ja ==="
    Call PrintFolders(root, "")
End Sub


Sub UjEmailSablonbol_1()
' DoWtHen Makr� 2026.05.01
' Sablon lev�l f�jl megny�t�sa

    Dim MyItem As Outlook.MailItem
    Dim path As String
    Dim fajlNev As String

fajlNev = "dwh.oft"
path = Environ$("APPDATA") & "\Microsoft\Templates\" & fajlNev
Set MyItem = Application.CreateItemFromTemplate(path)

    MyItem.Display
End Sub


Sub UjEmailSablonbol_2()
' DoWtHen Makr� 2026.05.01
' Sablon lev�l f�jl megny�t�sa

    Dim MyItem As Outlook.MailItem
    Dim path As String
    Dim fajlNev As String

fajlNev = "proba2.oft"
path = Environ$("APPDATA") & "\Microsoft\Templates\" & fajlNev
Set MyItem = Application.CreateItemFromTemplate(path)
    
    MyItem.Display
End Sub


Sub UjEmailFoxconn()
' DoWtHen Makr� 2026.05.01
' Sablon lev�l f�jl megny�t�sa

    Dim MyItem As Outlook.MailItem
    Dim path As String
    Dim fajlNev As String

fajlNev = "foxconn.oft"
path = Environ$("APPDATA") & "\Microsoft\Templates\" & fajlNev
Set MyItem = Application.CreateItemFromTemplate(path)

    MyItem.Display
End Sub


Sub TemplatesMappaMegnyitasa()
' DoWtHen Makr� 2026.09.12
' Megnyitja a Templates mapp�t

    Dim path As String
    path = Environ$("APPDATA") & "\Microsoft\Templates\"
    Shell "explorer.exe """ & path & """", vbNormalFocus
End Sub

