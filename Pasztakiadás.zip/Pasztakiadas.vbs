' ***********************************
' *         VBScript �rta:          *
' *            DoWtHen              *
' *  a Dakadran Oldala weboldalnak  *
' *       https://dakadran.hu       *
' *   Paszta kiad�s automata v1.1   *
' *       Copilot seg�ts�ggel       *
' *           2026.06.20.           *
' ***********************************

Dim oShell, KezdoIdo, Kesleltetes, PasztaKiadas
Set oShell = CreateObject("WScript.Shell")

KezdoIdo = Time

   ' Kezd� id� kiv�laszt�sa  	csak 1 felt�teles
   If Time <= TimeValue("06:30")  Then	
	 MsgBox "Reggeles vagy 10:00-kor adj ki Pasz�t!"
	 Kesleltetes = TimeValue("10:00") - KezdoIdo
   Elseif Time <= TimeValue("14:30") Then
   	 MsgBox "D�lut�nos vagy 18:00-kor adj ki Pasz�t!"
	  Kesleltetes = TimeValue("18:00") - KezdoIdo
   Elseif Time <= TimeValue("22:30") Then
   	 MsgBox "�jszak�s vagy 2:00-kor adj ki Pasz�t!"
	  Kesleltetes = TimeValue("2:00") - KezdoIdo
	  If Kesleltetes < 0 Then Kesleltetes = Kesleltetes + 1
   End If

   ' =================================================================


   ' Kezd� id� kiv�laszt�sa  	t�l - ig  id�korl�ttal 
'   If Time >= TimeValue("05:40") And Time <= TimeValue("06:30")  Then	
'	 MsgBox "itt kell reggeli 4 �r�t hozz�adni"
'	 Kesleltetes = TimeValue("10:00") - KezdoIdo
'   Elseif Time >= TimeValue("13:40") And Time <= TimeValue("14:30") Then
'   	 MsgBox "itt kell d�lut�ni 4 �r�t hozz�adni"
'	  Kesleltetes = TimeValue("18:00") - KezdoIdo
'   Elseif Time >= TimeValue("21:40") And Time <= TimeValue("22:30") Then
'   	 MsgBox "itt kell Esti 4 �r�t hozz�adni"
'	  Kesleltetes = TimeValue("2:00") - KezdoIdo
'	  If Kesleltetes < 0 Then Kesleltetes = Kesleltetes + 1
'   End If

	' �tv�lt�s milisecundumra
	PasztaKiadas = Kesleltetes * 24*60*60*1000 'Copilot ezt javasolta v�lt�shoz
	'WScript.Echo PasztaKiadas

	' V�rakoz�s
	WScript.sleep PasztaKiadas ' Le�ll�t�si id� k�sleltet�s
	
	' Futtat�s
	oShell.run "figyelem.png"
	oShell.Run "powershell -c (New-Object Media.SoundPlayer 'C:\Windows\Media\Alarm03.wav').PlaySync()", 0, True ' megnyitja a hangot de nincs Media Player ablak
	'oShell.run "c:\Windows\Media\Alarm03.wav" ' ez megnyitja a Media Playert