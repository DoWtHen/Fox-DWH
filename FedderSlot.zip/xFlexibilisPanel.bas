Attribute VB_Name = "xFlexibilisPanel"
Public Sub Mutasda_Panelt()
' DoWtHen makr� 2025.12.14
' Munkalap aktiv�l�s esem�ny
    
    MsgBox "A panel makr�it a Feeder-Slot f�jlokhoz �rtam!" & vbCrLf & Space(7) & "CSAK AZON FUTTASD!", vbCritical, "FIGYELMEZTET�S"
  With UserForm1
    .StartUpPosition = 0
    .Left = 0
    .Top = 120
    .Show vbModeless
  End With
End Sub
