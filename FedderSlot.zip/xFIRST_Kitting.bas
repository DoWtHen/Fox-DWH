Attribute VB_Name = "xFIRST_Kitting"
'==========================================
'     Feeder-Slot t�bl�zat l�trehoz�sa
'                  FoxConn
'==========================================

Sub Adatok_lapok_letrehozasa()
' Els� l�p�s
' DoWtHen Makr� 2026.11.12
' Munkalapok l�trehoz�sa

Dim wb As Workbook

Set wb = ActiveWorkbook

wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count)).Name = "Adatok_A"
Range("A1") = "M�sold ide a  BOT  oldal feeder PDF tartalm�t."
wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count)).Name = "Adatok_B"
Range("A1") = "M�sold ide a  TOP  oldal feeder PDF tartalm�t."
Sheets("Adatok_A").Select
End Sub


Sub Tablazat_formazasa()
' M�sodik l�p�s
' DoWtHen Makr� 2026.11.12
' T�bl�zatok form�z�sa

Dim a As Long
Dim LastRow As Long

adatLapok = Array("Adatok_A", "Adatok_B")

  For a = 0 To 1
    Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Sheets(adatLapok(a)).Select
    Columns("A:A").ColumnWidth = 8.45
    Columns("B:B").ColumnWidth = 7.73
    Columns("C:C").ColumnWidth = 26
    Columns("D:D").ColumnWidth = 5
    Range("A1").Select
  Next a
    Sheets("Adatok_A").Select
End Sub


Sub Szamsor_Feltoltes()
' Harmadik l�p�s
' DoWtHen Makr� 2026.11.12
' A hi�nyos sorok felt�lt�se Feeder-sz�mmal

Dim a As Long
Dim i As Long
Dim LastRow As Long

adatLapok = Array("Adatok_A", "Adatok_B")

  For a = 0 To 1
    Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Sheets(adatLapok(a)).Select
    LastRow = Cells(Rows.Count, "A").End(xlUp).row
    
    For i = 2 To LastRow
     If Cells(i, "A").Value = "" Then

        If Cells(i, "B").Value = "R" Then
            Cells(i, "A").Value = Cells(i - 1, "A").Value

        ElseIf Cells(i, "B").Value = "L" Then
            Cells(i, "A").Value = Cells(i + 1, "A").Value
        End If
     End If
    Next i
  Next a
    Sheets("Adatok_A").Select
    MsgBox "K�sz vagyok!"
End Sub


' NEM M�K�DIK
Sub Ures_Sorok_Torlese()
' Csak akkor m�k�dik, ha �rt�kk�nt van beillesztve a t�bl�zat az Adatok munkalapokra!

    Dim LastRow As Long
    Dim i As Long

    LastRow = Cells(Rows.Count, "A").End(xlUp).row

    For i = LastRow To 1 Step -1
        If WorksheetFunction.CountA(Range("A" & i & ":D" & i)) = 0 Then
            Rows(i).Delete
        End If
    Next i

End Sub

' NEM M�K�DIK
Sub UresSorokTorleseGyorsan()

    Dim LastRow As Long
    Dim rng As Range

    LastRow = Cells(Rows.Count, "A").End(xlUp).row

    With Range("A1:D" & LastRow)
        .AutoFilter Field:=1, Criteria1:="="
        .AutoFilter Field:=2, Criteria1:="="
        .AutoFilter Field:=3, Criteria1:="="
        .AutoFilter Field:=4, Criteria1:="="

        On Error Resume Next
        Set rng = .Offset(1).Resize(.Rows.Count - 1).SpecialCells(xlCellTypeVisible)
        On Error GoTo 0

        If Not rng Is Nothing Then rng.EntireRow.Delete

        ActiveSheet.AutoFilterMode = False
    End With

End Sub


Sub Feeder_Adat_Feltoltes()
' Negyedik l�p�s
' DoWtHen Makr� 2026.11.12
'Feeder dbsz�m felt�lt�s, form�z�s

Dim UtolsoA As Long

    Sheets("Sheet1").Select

UtolsoA = Range("A" & Rows.Count).End(xlUp).row  'A oszlop utols� cella sz�ma

' Fejl�c l�trehoz�sa, form�z�sa
    Range("C1").Select
    
    With Selection.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:= _
        xlBetween, Formula1:="L1,L2"
        .IgnoreBlank = True
        .InCellDropdown = True
        .InputTitle = ""
        .ErrorTitle = ""
        .InputMessage = ""
        .ErrorMessage = ""
        .ShowInput = True
        .ShowError = True
    End With
    With Selection.Interior
        .Color = 65535
    End With
    Range("C1") = "L1"
    
    Range("D1").Select
    With Selection.Interior
        .ThemeColor = xlThemeColorAccent2
        .TintAndShade = 0.599993896298105
    End With
    ActiveCell.FormulaR1C1 = "5000"
    Range("D1").Select
    Selection.NumberFormat = "General"" db"""
    
' K�plet bem�sol�sa C �s D oszlopba
Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Range("C2").Formula = "=IF(LEFT(A2,4)=$C$1&""A_"",XLOOKUP(MID(A2,5,10),Adatok_A!A:A&Adatok_A!B:B,Adatok_A!D:D,""""),IF(LEFT(A2,4)=$C$1&""B_"",XLOOKUP(MID(A2,5,10),Adatok_B!A:A&Adatok_B!B:B,Adatok_B!D:D,""""),""""))"  'angol verzi�
    Range("C2").AutoFill Destination:=Range("C2:C" & UtolsoA)
    
 Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Range("D2").Formula = "=IFERROR(C2*$D$1,"""")"
    Range("D2").AutoFill Destination:=Range("D2:D" & UtolsoA)
End Sub


Sub FIRST_kereses()
' �t�dik l�p�s
' DoWtHen Makr� 2026.11.12
' Foxconn seg�dlet
' kitting FIRST lista kieg�sz�t�s a l�da sz�mokkal
' Copolit seg�ts�g�vel (egyszer�s�t�s, optimaliz�l�s)

' - MARAD -

Dim wb As Workbook
Dim kittingWB As Workbook
Dim feederWB As Workbook
Dim UtolsoH As Long
Dim UtolsoA As Long
Dim UtolsoK As Long
Dim i As Long

 'INNEN m�sold az anyagsz�mokat
  For Each wb In Workbooks
    If wb.Name Like "*�sszek�t�tt*kittingelni.xlsx" Then
      Set kittingWB = wb
      Exit For
    End If
  Next wb

  If kittingWB Is Nothing Then
    MsgBox "Nem tal�lhat� a *�sszek�t�tt*kittingelni.xlsx f�jl!"
    Exit Sub
  End If
 'INNEN m�sold az anyagsz�mokat

 'IDE m�sold az anyagsz�mokat
  For Each wb In Workbooks
    If wb.Name Like "*_Devided_feeders.xlsx" Then
      Set feederWB = wb
      Exit For
    End If
  Next wb

  If feederWB Is Nothing Then
    MsgBox "Nem tal�lhat� a *_Devided_feeders.xlsx f�jl!"
    Exit Sub
  End If
 'IDE m�sold az anyagsz�mokat
 
 ' FIGYELMEZTET�S INFO sz�veg
  If MsgBox(Space(16) & "A FIRST lista f�jlt eg�sz�tem ki." & vbCrLf & "Az anyagsz�mok mell� �rom melyik l�d�ban tal�lod meg" & vbCrLf & "az adott alkatr�szt." _
  & vbCrLf & vbCrLf & "A ""kitting lista"" f�jb�l �tm�solom az anyagsz�mokat" & vbCrLf & "a FIRST lista ""Devided_feeders"" f�jlba!" & vbCrLf & vbCrLf & _
    "!! Lehet�leg csak ez a k�t excel f�jl legyen megnyitva !!" & vbCrLf & _
    "  --------------------------------------------------------" & vbCrLf & vbCrLf & _
    "Ebb�l a f�jlb�l m�solom: -Kitting lista-" & vbCrLf & kittingWB.Name & vbCrLf & vbCrLf & _
    "Ebbe a f�lba illesztem be: -First lista-" & vbCrLf & feederWB.Name & vbCrLf & vbCrLf & _
    "Biztosan futtatod a makr�t?", vbQuestion + vbYesNo, "FIRST anyag keres�s") = vbNo Then
    MsgBox "Akkor kil�pek.", vbInformation, "M�gsem"
    Exit Sub
  End If
 
 'Anyagsz�m-lista M�sol�s
    kittingWB.Activate
 
UtolsoH = kittingWB.ActiveSheet.Cells(kittingWB.ActiveSheet.Rows.Count, "H").End(xlUp).row 'H oszlop utols� cella sz�ma
 
    kittingWB.ActiveSheet.Range("H1:J" & UtolsoH).Copy
    feederWB.ActiveSheet.Range("K1").PasteSpecial Paste:=xlPasteValues
    
 'K�plet l�trehoz�sa
    feederWB.Activate
  
UtolsoA = Range("A" & Rows.Count).End(xlUp).row  'A oszlop utols� cella sz�ma
UtolsoK = Range("K" & Rows.Count).End(xlUp).row  'K oszlop utols� cella sz�ma

  For i = 2 To UtolsoA
    If Cells(i, "C").HasFormula Then
        If Cells(i, "C").Value = "" Then
            Range("C" & i & ":J" & i).ClearContents 't�rli a c:J cella tartalm�t
            Range("C" & i & ":J" & i).Merge 'C:J cell�k egyes�t�se
            Cells(i, "C").Formula = _
            "=XLOOKUP(A" & i & ",K$2:K$" & UtolsoK & ",M$2:M$" & UtolsoK & ","""")"
            
            Range("A" & i & ":J" & i).Interior.Color = RGB(201, 201, 201)
        End If
    End If
  Next i
    
 '�tm�solt adatok t�rl�se
    Range("C1:D" & UtolsoA).Copy
    Range("C1").PasteSpecial Paste:=xlPasteValues
Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Range("K1:M" & UtolsoK).ClearContents
    Columns("A:A").ColumnWidth = 29
    Columns("B:C").ColumnWidth = 10
    Columns("D:D").ColumnWidth = 15
    Columns("E:I").ColumnWidth = 8.1
    Columns("J:J").ColumnWidth = 65
    
    Cells.Select
    Selection.Font.Size = 16
    Range("D1").Select
    Application.CutCopyMode = False
End Sub


