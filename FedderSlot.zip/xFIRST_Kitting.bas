Attribute VB_Name = "xFIRST_Kitting"
'==========================================
'     Feeder-Slot t�bl�zat l�trehoz�sa
'                  FoxConn
'==========================================
' v1 2026.11.12; beta teszt
' v2 2026.11.20; Adatok_ lapok n�v v�ltoztat�s
'   kis-nagybet� �rz�kenys�g kikpcsol�sa LCase paranccsal
'   oszt�sz�msor l�trehoz�sa a E F oszlopba
'   egy egyszer�bb First makr� (CSAK_FIRST_lista) a keres�shez + nyomtat�si be�ll�t�s
'   optimaliz�lt Feeder sz�m beilleszt�s �gy m�r nem terheli le a g�pet
'

'=====FIRST makr�i==========================

Sub CSAK_FIRST_lista()
' DoWtHen Makr� 2026.11.12
' Foxconn seg�dlet
' kitting FIRST lista kieg�sz�t�s a l�da sz�mokkal
' Copolit seg�ts�g�vel (egyszer�s�t�s, optimaliz�l�s)

Dim wb As Workbook
Dim kittingWB As Workbook
Dim feederWB As Workbook
Dim UtolsoH As Long
Dim UtolsoA As Long
Dim UtolsoK As Long

 'INNEN m�sold az anyagsz�mokat
  For Each wb In Workbooks
    If LCase(wb.Name) Like LCase("*�sszek�t�tt*kittingelni.xlsx") Then
      Set kittingWB = wb
      Exit For
    End If
  Next wb

  If kittingWB Is Nothing Then
    MsgBox "Nem tal�lhat� a *�sszek�t�tt*kittingelni.xlsx f�jl!"
    Exit Sub
  End If
 'INNEN m�sold az anyagsz�mokat

 'IDE m�sold az anyagsz�mokat
  For Each wb In Workbooks
    If LCase(wb.Name) Like LCase("*_Devided_feeders.xlsx") Then
      Set feederWB = wb
      Exit For
    End If
  Next wb

  If feederWB Is Nothing Then
    MsgBox "Nem tal�lhat� a *_Devided_feeders.xlsx f�jl!"
    Exit Sub
  End If
 'IDE m�sold az anyagsz�mokat
 
 ' FIGYELMEZTET�S INFO sz�veg
  If MsgBox(Space(16) & "A FIRST lista f�jlt eg�sz�tem ki." & vbCrLf & "Az anyagsz�mok mell� �rom melyik l�d�ban tal�lod meg" & vbCrLf & "az adott alkatr�szt." _
  & vbCrLf & vbCrLf & "A ""kitting lista"" f�jb�l �tm�solom az anyagsz�mokat" & vbCrLf & "a FIRST lista ""Devided_feeders"" f�jlba!" & vbCrLf & vbCrLf & _
    "!! Lehet�leg csak ez a k�t excel f�jl legyen megnyitva !!" & vbCrLf & _
    "  --------------------------------------------------------" & vbCrLf & vbCrLf & _
    "Ebb�l a f�jlb�l m�solom: -Kitting lista-" & vbCrLf & kittingWB.Name & vbCrLf & vbCrLf & _
    "Ebbe a f�lba illesztem be: -First lista-" & vbCrLf & feederWB.Name & vbCrLf & vbCrLf & _
    "Biztosan futtatod a makr�t?", vbQuestion + vbYesNo, "CSAK FIRST lista") = vbNo Then
    MsgBox "Akkor kil�pek.", vbInformation, "M�gsem"
    Exit Sub
  End If
 
 'Anyagsz�m-lista M�sol�s
    kittingWB.Activate
 
UtolsoH = kittingWB.ActiveSheet.Cells(kittingWB.ActiveSheet.Rows.Count, "H").End(xlUp).row 'H oszlop utols� cella sz�ma
 
    kittingWB.ActiveSheet.Range("H1:J" & UtolsoH).Copy
    'feederWB.ActiveSheet.Range("K1").PasteSpecial Paste:=xlPasteValues
    feederWB.Sheets("Sheet1").Range("K1").PasteSpecial Paste:=xlPasteValues
     '   Sheets("Sheet1").Select
 'K�plet l�trehoz�sa
    feederWB.Activate
  
UtolsoA = Range("A" & Rows.Count).End(xlUp).row  'A oszlop utols� cella sz�ma
UtolsoK = Range("K" & Rows.Count).End(xlUp).row  'K oszlop utols� cella sz�ma
    
    Range("C2").Formula = "=XLOOKUP(A2,K$2:K$" & UtolsoK & ",M$2:M$" & UtolsoK & ","""")"  'angol verzi�
    Range("C2").AutoFill Destination:=Range("C2:C" & UtolsoA)
    
    Range("C2:C" & UtolsoA).Value = Range("C2:C" & UtolsoA).Value
    Columns("C:C").EntireColumn.AutoFit 'oszlop sz�th�z�sa
    
 '�tm�solt adatok t�rl�se
    Range("K1:M" & UtolsoK).ClearContents
    Range("C1") = "    L�DA sz�mok"
    Range("C1").Select
    Application.CutCopyMode = False
End Sub


Sub FIRST_Nyomtatas()
' DoWtHen Makr� 2026.11.12
' FIRST lista optim�lis nyomtat�s�hoz

  With ActiveSheet
    .PageSetup.PrintArea = "$A$1:$C$" & Cells(Rows.Count, "A").End(xlUp).row
    
    With .PageSetup
        .Orientation = xlPortrait
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .LeftFooter = "&14Oldal &P"
        .RightFooter = "&14Oldal &P / &N"
    End With
    
    'ler�vid�ttem a C oszlopot, hogy csak egy lapnyi l�tsz�djon a sz�vegb�l
    Columns("C").ColumnWidth = 50 ' HA nem f�r ki egylapra ezen az �rt�ken kell v�ltoztatni

    .PrintPreview 'el�n�zeti k�p
    '.PrintOut 'nyomtat�s
    
    'vissza�ll�tom a sz�less�get
    Columns("C").AutoFit 'oszlop sz�th�z�sa
    .PageSetup.PrintArea = ""      ' Nyomtat�si ter�let t�rl�se
  End With
End Sub


'=====SLOTOL�S makr�i==========================

Sub Adatok_lapok_letrehozasa()
' Els� l�p�s
' DoWtHen Makr� 2026.11.12
' Munkalapok l�trehoz�sa

Dim wb As Workbook

Set wb = ActiveWorkbook

wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count)).Name = "Adatok_BOT"
Range("A1") = "M�sold ide a  BOT  oldal feeder PDF tartalm�t."
wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count)).Name = "Adatok_TOP"
Range("A1") = "M�sold ide a  TOP  oldal feeder PDF tartalm�t."
Sheets("Adatok_BOT").Select
End Sub


'M�sodik l�p�s a PDF bem�sol�sa k�zzel.


Sub Tablazat_formazasa()
' Harmadik /A l�p�s
' DoWtHen Makr� 2026.11.12
' T�bl�zatok form�z�sa

Dim a As Long
Dim LastRow As Long

adatLapok = Array("Adatok_BOT", "Adatok_TOP")

  For a = 0 To 1
    Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Sheets(adatLapok(a)).Select
    Columns("A:A").ColumnWidth = 8.45
    Columns("B:B").ColumnWidth = 6.73
    Columns("C:C").ColumnWidth = 26
    Columns("D:D").ColumnWidth = 5
    Range("A1").Select
  Next a
    Sheets("Adatok_BOT").Select
End Sub


Sub UresSorokTorleseGyorsan()
' Harmadik /B l�p�s
' DoWtHen Makr� 2026.11.12
' Csak akkor m�k�dik, ha �rt�kk�nt van beillesztve a t�bl�zat az Adatok munkalapokra!

Dim LastRow As Long
Dim rng As Range

If MsgBox("Ezt a makr�t k�l�n le kell futtatni" & vbCrLf & "az ADATOK_BOT - Adatok_TOP lapokon!" & vbCrLf & vbCrLf & "CSAK akkor futtasd, ha a t�bl�zat �RT�KK�NT van beillesztve!", vbCritical + vbYesNo, "Figyelmeztet�s") = vbNo Then
    MsgBox "Akkor kil�pek.", vbInformation, "M�gsem"
    Exit Sub
End If

LastRow = Cells(Rows.Count, "A").End(xlUp).row
  With Range("A1:D" & LastRow)
    .AutoFilter Field:=1, Criteria1:="="
    .AutoFilter Field:=2, Criteria1:="="
    .AutoFilter Field:=3, Criteria1:="="
    .AutoFilter Field:=4, Criteria1:="="

    On Error Resume Next
    Set rng = .Offset(1).Resize(.Rows.Count - 1).SpecialCells(xlCellTypeVisible)
    On Error GoTo 0

    If Not rng Is Nothing Then rng.EntireRow.Delete

    ActiveSheet.AutoFilterMode = False
  End With

End Sub


Sub Szamsor_Feltoltes()
' Negyedik l�p�s
' DoWtHen Makr� 2026.11.12
' A hi�nyos sorok felt�lt�se Feeder-sz�mmal

Dim a As Long
Dim i As Long
Dim LastRow As Long

adatLapok = Array("Adatok_BOT", "Adatok_TOP")

  For a = 0 To 1
    Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Sheets(adatLapok(a)).Select
    LastRow = Cells(Rows.Count, "A").End(xlUp).row
    
    For i = 2 To LastRow
     If Cells(i, "A").Value = "" Then

        If Cells(i, "B").Value = "R" Then
            Cells(i, "A").Value = Cells(i - 1, "A").Value

        ElseIf Cells(i, "B").Value = "L" Then
            Cells(i, "A").Value = Cells(i + 1, "A").Value
        End If
     End If
    Next i
  Next a
    Sheets("Adatok_BOT").Select
    MsgBox "K�sz vagyok!"
End Sub


Sub VegzodesTorles()
' �t�dik /A l�p�s
' DoWtHen Makr� 2026.11.12
'Feeder dbsz�m form�z�s -1 karakter elt�vol�t�sa

Dim UtolsoSor As Long
Dim Cella As Range

    Sheets("Sheet1").Select

UtolsoSor = Cells(Rows.Count, "A").End(xlUp).row

' -1 elt�vol�t�s a Feeder sz�mokb�l
  For Each Cella In Range("A2:A" & UtolsoSor)
    If Right(Cella.Value, 2) = "-1" Then
       Cella.Value = Left(Cella.Value, Len(Cella.Value) - 2)
    End If
  Next Cella
  
    MsgBox " T�r�ltem a Feeder sz�mok ""-1"" v�gz�d�s� karaktereit.", , "T�rl�s"
End Sub


Sub Feeder_Adat_Feltoltes()
' �t�dik /B l�p�s
' DoWtHen Makr� 2026.11.12
'Feeder dbsz�m felt�lt�s, form�z�s
' Copilot seg�ts�g�vel (egyszer�s�t�s, optimaliz�l�s)

Dim UtolsoA As Long

On Error GoTo Hiba

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

  With Sheets("Sheet1")

  UtolsoA = .Cells(.Rows.Count, "A").End(xlUp).row

  With .Range("C1")
    .Validation.Delete

    .Validation.Add _
        Type:=xlValidateList, _
        AlertStyle:=xlValidAlertStop, _
        Operator:=xlBetween, _
        Formula1:="L1,L2"

    .Interior.Color = 65535
    .Value = "L1"
  End With

        ' D1 form�z�s
  With .Range("D1")
    .Interior.ThemeColor = xlThemeColorAccent2
    .Interior.TintAndShade = 0.599993896298105
    .Value = 5000
    .NumberFormat = "General"" db"""
  End With
    
    ' E �s F fejl�c
    .Range("E1").Value = "Oszt�sz�m"
    .Range("F1").Value = "Tekercsek sz�ma"
    
    ' C oszlop k�plet
    ' 500 sorban keres az ADATOK_ lapjain!
    .Range("C2:C" & UtolsoA).Formula2 = _
    "=IF(LEFT(A2,4)=$C$1&""A_""," & _
    "XLOOKUP(MID(A2,5,10),Adatok_BOT!A$2:A$500&Adatok_BOT!B$2:B$500,Adatok_BOT!D$2:D$500,"""")," & _
    "IF(LEFT(A2,4)=$C$1&""B_""," & _
    "XLOOKUP(MID(A2,5,10),Adatok_TOP!A$2:A$500&Adatok_TOP!B$2:B$500,Adatok_TOP!D$2:D$500,""""),""""))"
    
    .Columns("C:C").ColumnWidth = 8.05
    
    ' D oszlop k�plet
    .Range("D2:D" & UtolsoA).Formula = "=IFERROR(C2*$D$1,"""")"
    
    ' F oszlop k�plet
    .Range("F2:F" & UtolsoA).Formula = "=IFERROR($D2/$E2,"""")"
  End With

Kilepes:
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate

    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Exit Sub

Hiba:
    MsgBox Err.Description, vbExclamation
    Resume Kilepes
End Sub


Sub FIRST_kereses()
' Hatodik /A l�p�s
' DoWtHen Makr� 2026.11.12
' Foxconn seg�dlet
' kitting FIRST lista kieg�sz�t�s a l�da sz�mokkal
' Copolit seg�ts�g�vel (egyszer�s�t�s, optimaliz�l�s)

' - MARAD -

Dim wb As Workbook
Dim kittingWB As Workbook
Dim feederWB As Workbook
Dim UtolsoH As Long
Dim UtolsoA As Long
Dim UtolsoK As Long
Dim i As Long

 'INNEN m�sold az anyagsz�mokat
  For Each wb In Workbooks
    If LCase(wb.Name) Like LCase("*�sszek�t�tt*kittingelni.xlsx") Then
      Set kittingWB = wb
      Exit For
    End If
  Next wb

  If kittingWB Is Nothing Then
    MsgBox "Nem tal�lhat� a *�sszek�t�tt*kittingelni.xlsx f�jl!"
    Exit Sub
  End If
 'INNEN m�sold az anyagsz�mokat

 'IDE m�sold az anyagsz�mokat
  For Each wb In Workbooks
    If LCase(wb.Name) Like LCase("*_Devided_feeders.xlsx") Then
      Set feederWB = wb
      Exit For
    End If
  Next wb

  If feederWB Is Nothing Then
    MsgBox "Nem tal�lhat� a *_Devided_feeders.xlsx f�jl!"
    Exit Sub
  End If
 'IDE m�sold az anyagsz�mokat
 
 ' FIGYELMEZTET�S INFO sz�veg
  If MsgBox(Space(16) & "A FIRST lista f�jlt eg�sz�tem ki." & vbCrLf & "Az anyagsz�mok mell� �rom melyik l�d�ban tal�lod meg" & vbCrLf & "az adott alkatr�szt." _
  & vbCrLf & vbCrLf & "A ""kitting lista"" f�jb�l �tm�solom az anyagsz�mokat" & vbCrLf & "a FIRST lista ""Devided_feeders"" f�jlba!" & vbCrLf & vbCrLf & _
    "!! Lehet�leg csak ez a k�t excel f�jl legyen megnyitva !!" & vbCrLf & _
    "  --------------------------------------------------------" & vbCrLf & vbCrLf & _
    "Ebb�l a f�jlb�l m�solom: -Kitting lista-" & vbCrLf & kittingWB.Name & vbCrLf & vbCrLf & _
    "Ebbe a f�lba illesztem be: -First lista-" & vbCrLf & feederWB.Name & vbCrLf & vbCrLf & _
    "Biztosan futtatod a makr�t?", vbQuestion + vbYesNo, "FIRST anyag keres�s") = vbNo Then
    MsgBox "Akkor kil�pek.", vbInformation, "M�gsem"
    Exit Sub
  End If
 
 'Anyagsz�m-lista M�sol�s
    kittingWB.Activate
 
UtolsoH = kittingWB.ActiveSheet.Cells(kittingWB.ActiveSheet.Rows.Count, "H").End(xlUp).row 'H oszlop utols� cella sz�ma
 
    kittingWB.ActiveSheet.Range("H1:J" & UtolsoH).Copy
    feederWB.ActiveSheet.Range("K1").PasteSpecial Paste:=xlPasteValues
    
 'K�plet l�trehoz�sa
    feederWB.Activate
  
UtolsoA = Range("A" & Rows.Count).End(xlUp).row  'A oszlop utols� cella sz�ma
UtolsoK = Range("K" & Rows.Count).End(xlUp).row  'K oszlop utols� cella sz�ma

  For i = 2 To UtolsoA
    If Cells(i, "C").HasFormula Then
        If Cells(i, "C").Value = "" Then
            Range("C" & i & ":J" & i).ClearContents 't�rli a C:J cella tartalm�t
            Range("C" & i & ":J" & i).Merge 'C:J cell�k egyes�t�se
            Cells(i, "C").Formula = _
            "=XLOOKUP(A" & i & ",K$2:K$" & UtolsoK & ",M$2:M$" & UtolsoK & ","""")"
            
            Range("A" & i & ":J" & i).Interior.Color = RGB(201, 201, 201)
        End If
    End If
  Next i
    
 '�tm�solt adatok t�rl�se
    Range("C1:D" & UtolsoA).Copy
    Range("C1").PasteSpecial Paste:=xlPasteValues
Application.Wait (Now + TimeValue("0:00:01")) ' Egy kis sz�net
    Range("K1:M" & UtolsoK).ClearContents

End Sub


Sub VegeFormazas()
' Hatodik /B l�p�s
' DoWtHen Makr� 2026.11.21
' V�gs� form�z�sok a Feeder lapon

Dim UtolsoSor As Long

UtolsoSor = Cells(Rows.Count, "A").End(xlUp).row

Application.Wait (Now + TimeValue("0:00:02")) ' Egy kis sz�net

    Columns("A:A").ColumnWidth = 29
    Columns("B:C").ColumnWidth = 10
    Columns("D:D").ColumnWidth = 15
    Columns("E:I").ColumnWidth = 8.1
    Columns("J:J").ColumnWidth = 55
    
    Cells.Select
    Selection.Font.Size = 12
    
    'Oszt�sz�m oszt�s form�z�sai
    Range("E:E").Font.Size = 8
    Range("F1").Font.Size = 8
    
    Application.CutCopyMode = False
    
    Range("A2").Select
    ActiveWindow.FreezePanes = True
    Range("D1").Select

' Sor sz�nez�s
UtolsoSor = Cells(Rows.Count, "A").End(xlUp).row

  For i = 2 To UtolsoSor
    If Left(Cells(i, "A").Value, 4) = "L1A_" _
      Or Left(Cells(i, "A").Value, 4) = "L2A_" Then
        Range("A" & i & ":F" & i).Interior.Color = RGB(255, 242, 204) 's�rga
    End If
  Next i
End Sub
