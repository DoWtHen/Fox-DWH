VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} UserForm1 
   Caption         =   "Feeder-Slot t�bl�zat l�trehoz�sa"
   ClientHeight    =   11010
   ClientLeft      =   110
   ClientTop       =   450
   ClientWidth     =   4010
   OleObjectBlob   =   "UserForm1.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "UserForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub CommandButton1_Click()
Adatok_lapok_letrehozasa
End Sub

Private Sub CommandButton2_Click()
Tablazat_formazasa
End Sub

Private Sub CommandButton3_Click()
Szamsor_Feltoltes
End Sub

Private Sub CommandButton4_Click()
Feeder_Adat_Feltoltes
End Sub

Private Sub CommandButton5_Click()
FIRST_kereses
End Sub



Private Sub UserForm_Initialize()
    
    With Me.Label3
        .Caption = "Els� l�p�s;" & vbCrLf & _
                   "   Munkalapok l�trehoz�sa."
    End With
    
    With Me.Label4
        .Caption = "M�sodik l�p�s;" & vbCrLf & _
                   "   PDF manu�lis konvert�l�sa." & vbCrLf & _
                   "Figyelj az �res sorok t�rl�s�n�l!"
    End With

    With Me.Label5
        .Caption = "Harmadik l�p�s;" & vbCrLf & _
                   "   T�bl�zat form�z�sa."
    End With
    
    With Me.Label6
        .Caption = "Negyedik l�p�s;" & vbCrLf & _
                   "   Sz�msor felt�lt�se." & vbCrLf & _
                   "T�bbsz�r is lefuttathat�."
    End With

    With Me.Label7
        .Caption = "�t�dik l�p�s;" & vbCrLf & _
                   "   A Feeder sz�mok p�tl�sa."
    End With
    
    With Me.Label8
        .Caption = "Hatodik l�p�s;" & vbCrLf & _
                   "   A FIRST lista dbsz�mmal felt�lt�se."
    End With
    
End Sub

